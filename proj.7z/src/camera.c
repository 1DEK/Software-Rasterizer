#include "camera.h"

// TODO this is hacky and only works for 1x1x1x1x1x1 soylent normal cameras.
vec3 canvasToViewport(int x, int y, const canvas *canvas, const camera *camera)
{
	return (vec3){x*camera->width/canvas->width, y*camera->height/canvas->height, camera->depth};
}
