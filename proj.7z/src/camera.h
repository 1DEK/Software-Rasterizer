#ifndef CAMERA_H
#define CAMERA_H

#include "vector.h"
#include "canvas.h"

/*

Coordinate system:

 y
 ^
 |       
 |       z
 |      ^ 
 |     /
 |    /
 |   /
 |  /
 | /
   ---------------------- > x

*/

// TODO actually make the camera work properly and not just be a 1x1x1x1x1x1x1.... normal thing
typedef struct Camera
{
	vec3 position;
	vec3 direction; // unit vector indicating where the camera is pointing
	vec3 up; // which way is up
	float width; // viewport width
	float height; // viewport height
	float depth; // viewport depth.... TODO is this the right term?
} camera;

vec3 canvasToViewport(int x, int y, const canvas *canvas, const camera *camera);

#endif // CAMERA_H
