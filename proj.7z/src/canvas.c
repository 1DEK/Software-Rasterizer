#include "canvas.h"
#include <stdlib.h>

canvas *createCanvas(int width, int height)
{
	canvas *canvas = malloc(sizeof(*canvas));
	if (canvas == NULL)
	{
		return NULL;
	}
	canvas->width = width;
	canvas->height = height;
	
	canvas->pixels = malloc(height*sizeof(*canvas->pixels));
	if (canvas->pixels == NULL)
	{
		free(canvas);
		return NULL;
	}

	for (int i = 0; i < height; i++)
	{
		canvas->pixels[i] = malloc(width*sizeof(*canvas->pixels[i]));
		if (canvas->pixels[i] == NULL)
		{
			for (int j = 0; j < i; j++)
			{
				free(canvas->pixels[j]);
			}
			free(canvas->pixels);
			free(canvas);
			return NULL;
		}
	}

	return canvas;
}

void deleteCanvas(canvas *canvas)
{
	for (int i = 0; i < canvas->height; i++)
	{
		free(canvas->pixels[i]);
	}
	free(canvas->pixels);
	free(canvas);
}

int clamp(int value, int min, int max)
{
	return value < min ? min : (value > max ? max : value);
}

void putPixel(int x, int y, color color, const canvas *canvas)
{
	canvas->pixels[canvas->height/2 - y][canvas->width/2 + x] = color;
}

void clearCanvas(color color, const canvas *canvas)
{
	for (int i = 0; i < canvas->height; i++)
	{
		for (int j = 0; j < canvas->width; j++)
		{
			canvas->pixels[i][j] = color;
		}
	}
}

void writeCanvasToFile(const canvas *canvas, FILE *outfile)
{
	fputs("P3\n", outfile);
	fprintf(outfile, "%d %d\n255\n", canvas->width, canvas->height);
	for (int i = 0; i < canvas->height; i++)
	{
		for (int j = 0; j < canvas->width; j++)
		{
			fprintf(outfile, "%d %d %d ", canvas->pixels[i][j].r, canvas->pixels[i][j].g, canvas->pixels[i][j].b);
		}
		fputc('\n', outfile);
	}
}
