#ifndef CANVAS_H
#define CANVAS_H

#include <stdio.h>

typedef struct Color
{
	int r, g, b;
} color;

typedef struct Canvas
{
	color **pixels;
	int width;
	int height;
} canvas;

canvas *createCanvas(int width, int height);

void deleteCanvas(canvas *canvas);

int clamp(int value, int min, int max);

void putPixel(int x, int y, color color, const canvas *canvas);

void clearCanvas(color color, const canvas *canvas);

void writeCanvasToFile(const canvas *canvas, FILE *outfile);

#endif // CANVAS_H
