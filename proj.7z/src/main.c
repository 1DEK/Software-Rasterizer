#include "primitives.h"
#include <stdlib.h>
#include <time.h>

int randomInRange(int min, int max)
{
	return min + rand()%(max - min + 1);
}

int main(int argc, char **argv)
{
	srand(time(NULL));

	if (argc != 4)
	{
		puts("Usage: bin canvas_width canvas_height output_file");
		return 1;
	}

	FILE *outfile = fopen(argv[3], "w");
	if (outfile == NULL)
	{
		puts("Error: could not open output file");
		return 1;
	}

	canvas *canvas = createCanvas(atoi(argv[1]), atoi(argv[2]));
	if (canvas == NULL)
	{
		puts("Error: could not create a canvas of the requested size");
		fclose(outfile);
		return 1;
	}
	
	// do stuff to canvas
	clearCanvas((color){255, 255, 255}, canvas);
	// vec2 points[100];
	// for (int i = 0; i < 100; i++)
	// {
		// points[i].x = randomInRange(-250, 249);
		// points[i].y = randomInRange(-250, 249);
	// }
	// for (int i = 0; i < 100 - 2; i++)
	// {
		// putTriangle(points[i], points[i + 1], points[i + 2], (color){randomInRange(0, 255), randomInRange(0, 255), randomInRange(0, 255)}, canvas);
	// }
	triangle t = (triangle){
		(point){(vec2){-50, -50}, (color){255, 0, 0}},
		(point){(vec2){0, 50}, (color){0, 255, 0}},
		(point){(vec2){50, -50}, (color){0, 0, 255}}
	};
	drawShadedTriangle(t, canvas);
	t = (triangle){
		(point){(vec2){-50 + 150, -50 + 150}, (color){255, 255, 0}},
		(point){(vec2){0 + 150, 50 + 150}, (color){255, 255, 0}},
		(point){(vec2){50 + 150, -50 + 20}, (color){0, 0, 255}}
	};
	drawShadedTriangle(t, canvas);

	// then write it out to the file
	writeCanvasToFile(canvas, outfile);
	fclose(outfile);

	deleteCanvas(canvas);
	
	return 0;
}
