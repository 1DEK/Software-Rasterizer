#include "primitives.h"
#include <math.h>
#include <stdio.h>

void putLine(vec2 p1, vec2 p2, color color, const canvas *canvas)
{
	float dx = p2.x - p1.x;
	float dy = p2.y - p1.y;

	if (fabs(dy) > fabs(dx)) // more vertical
	{
		if (dy < 0.0)
		{
			vec2 temp = p1;
			p1 = p2;
			p2 = temp;
		}

		float m = dx/dy;
		float x = p1.x;
		for (int y = p1.y; y <= p2.y; y++)
		{
			putPixel(x, y, color, canvas);
			x += m;
		}
	}
	else // more horizantal
	{
		if (dx < 0.0)
		{
			vec2 temp = p1;
			p1 = p2;
			p2 = temp;
		}

		float m = dy/dx;
		float y = p1.y;
		for (int x = p1.x; x <= p2.x; x++)
		{
			putPixel(x, y, color, canvas);
			y += m;
		}
	}
}

void putTriangleWireframe(vec2 p1, vec2 p2, vec2 p3, color color, const canvas *canvas)
{
	putLine(p1, p2, color, canvas);
	putLine(p2, p3, color, canvas);
	putLine(p3, p1, color, canvas);
}

// top down scanline algorithm
void putTriangle(vec2 p1, vec2 p2, vec2 p3, color color, const canvas *canvas)
{
	// sort points by y coordinate
	if (p2.y > p1.y)
	{
		vec2 temp = p2;
		p2 = p1;
		p1 = temp;
	}
	if (p3.y > p2.y)
	{
		vec2 temp = p3;
		p3 = p2;
		p2 = temp;
	}
	if (p2.y > p1.y)
	{
		vec2 temp = p2;
		p2 = p1;
		p1 = temp;
	}

	// left pointing or right pointing?
	vec2 ab = vec2Sub(p1, p3);
	vec2 n = vec2Perp(ab);
	vec2 ad = vec2Sub(p2, p3);
	float dot = vec2Dot(ad, n);

	if (dot > 0.0) // right
	{
		float x0 = p1.x;
		float x1 = p1.x;
		float m0 = (p1.x - p3.x)/(p1.y - p3.y);
		float m1 = (p1.x - p2.x)/(p1.y - p2.y);
		for (int y = p1.y; y > p2.y; y--)
		{
			// we don't own the top side of the bend.
			for (int x = x0; x < x1; x++)
			{
				putPixel(x, y, color, canvas);
			}

			x0 -= m0;
			x1 -= m1;
		}

		x1 = p2.x;
		m1 = (p2.x - p3.x)/(p2.y - p3.y);
		for (int y = p2.y; y >= p3.y; y--)
		{
			for (int x = x0; x <= x1; x++)
			{
				putPixel(x, y, color, canvas);

			}
			
			x0 -= m0;
			x1 -= m1;
		}
	}
	else // left
	{
		float x0 = p1.x;
		float x1 = p1.x;
		float m0 = (p1.x - p3.x)/(p1.y - p3.y);
		float m1 = (p1.x - p2.x)/(p1.y - p2.y);
		for (int y = p1.y; y > p2.y; y--)
		{
			// we don't own the top side of the bend.
			for (int x = x0; x > x1; x--)
			{
				putPixel(x, y, color, canvas);
			}

			x0 -= m0;
			x1 -= m1;
		}

		x1 = p2.x;
		m1 = (p2.x - p3.x)/(p2.y - p3.y);
		for (int y = p2.y; y >= p3.y; y--)
		{
			for (int x = x0; x >= x1; x--)
			{
				putPixel(x, y, color, canvas);
			}
			
			x0 -= m0;
			x1 -= m1;
		}
	}
}

void drawShadedTriangle(triangle triangle, const canvas *canvas)
{
	// sort points by y coordinate
	point p1 = triangle.p1, p2 = triangle.p2, p3 = triangle.p3;
	if (p2.position.y > p1.position.y)
	{
		point temp = p2;
		p2 = p1;
		p1 = temp;
	}
	if (p3.position.y > p2.position.y)
	{
		point temp = p3;
		p3 = p2;
		p2 = temp;
	}
	if (p2.position.y > p1.position.y)
	{
		point temp = p2;
		p2 = p1;
		p1 = temp;
	}

	// left pointing or right pointing?
	vec2 ab = vec2Sub(p1.position, p3.position);
	vec2 n = vec2Perp(ab);
	vec2 ad = vec2Sub(p2.position, p3.position);
	float dot = vec2Dot(ad, n);

	float triangleArea = vec3Mag(vec2Cross(ab, vec2Sub(p2.position, p3.position)));

	if (dot > 0.0) // right
	{
		float x0 = p1.position.x;
		float x1 = p1.position.x;
		float m0 = (p1.position.x - p3.position.x)/(p1.position.y - p3.position.y);
		float m1 = (p1.position.x - p2.position.x)/(p1.position.y - p2.position.y);
		for (int y = p1.position.y; y > p2.position.y; y--)
		{
			// we don't own the top side of the bend.
			for (int x = x0; x < x1; x++)
			{
				vec2 p = (vec2){x, y};
				vec2 p1_p = vec2Sub(p, p1.position);
				vec2 p2_p = vec2Sub(p, p2.position);
				vec2 p3_p = vec2Sub(p, p3.position);
				float alpha = vec3Mag(vec2Cross(p2_p, p3_p))/triangleArea;
				float beta = vec3Mag(vec2Cross(p1_p, p3_p))/triangleArea;
				float gamma = vec3Mag(vec2Cross(p1_p, p2_p))/triangleArea;
				color col = (color){
					clamp(alpha*p1.color.r, 0, 255) + clamp(beta*p2.color.r, 0, 255) + clamp(gamma*p3.color.r, 0, 255),
					clamp(alpha*p1.color.g, 0, 255) + clamp(beta*p2.color.g, 0, 255) + clamp(gamma*p3.color.g, 0, 255),
					clamp(alpha*p1.color.b, 0, 255) + clamp(beta*p2.color.b, 0, 255) + clamp(gamma*p3.color.b, 0, 255)
				};
				putPixel(x, y, col, canvas);
			}

			x0 -= m0;
			x1 -= m1;
		}

		x1 = p2.position.x;
		m1 = (p2.position.x - p3.position.x)/(p2.position.y - p3.position.y);
		for (int y = p2.position.y; y >= p3.position.y; y--)
		{
			for (int x = x0; x <= x1; x++)
			{
				vec2 p = (vec2){x, y};
				vec2 p1_p = vec2Sub(p, p1.position);
				vec2 p2_p = vec2Sub(p, p2.position);
				vec2 p3_p = vec2Sub(p, p3.position);
				float alpha = vec3Mag(vec2Cross(p2_p, p3_p))/triangleArea;
				float beta = vec3Mag(vec2Cross(p1_p, p3_p))/triangleArea;
				float gamma = vec3Mag(vec2Cross(p1_p, p2_p))/triangleArea;
				color col = (color){
					clamp(alpha*p1.color.r, 0, 255) + clamp(beta*p2.color.r, 0, 255) + clamp(gamma*p3.color.r, 0, 255),
					clamp(alpha*p1.color.g, 0, 255) + clamp(beta*p2.color.g, 0, 255) + clamp(gamma*p3.color.g, 0, 255),
					clamp(alpha*p1.color.b, 0, 255) + clamp(beta*p2.color.b, 0, 255) + clamp(gamma*p3.color.b, 0, 255)
				};
				putPixel(x, y, col, canvas);
			}
			
			x0 -= m0;
			x1 -= m1;
		}
	}
	else // left
	{
		float x0 = p1.position.x;
		float x1 = p1.position.x;
		float m0 = (p1.position.x - p3.position.x)/(p1.position.y - p3.position.y);
		float m1 = (p1.position.x - p2.position.x)/(p1.position.y - p2.position.y);
		for (int y = p1.position.y; y > p2.position.y; y--)
		{
			// we don't own the top side of the bend.
			for (int x = x0; x > x1; x--)
			{
				vec2 p = (vec2){x, y};
				vec2 p1_p = vec2Sub(p, p1.position);
				vec2 p2_p = vec2Sub(p, p2.position);
				vec2 p3_p = vec2Sub(p, p3.position);
				float alpha = vec3Mag(vec2Cross(p2_p, p3_p))/triangleArea;
				float beta = vec3Mag(vec2Cross(p1_p, p3_p))/triangleArea;
				float gamma = vec3Mag(vec2Cross(p1_p, p2_p))/triangleArea;
				color col = (color){
					clamp(alpha*p1.color.r, 0, 255) + clamp(beta*p2.color.r, 0, 255) + clamp(gamma*p3.color.r, 0, 255),
					clamp(alpha*p1.color.g, 0, 255) + clamp(beta*p2.color.g, 0, 255) + clamp(gamma*p3.color.g, 0, 255),
					clamp(alpha*p1.color.b, 0, 255) + clamp(beta*p2.color.b, 0, 255) + clamp(gamma*p3.color.b, 0, 255)
				};
				putPixel(x, y, col, canvas);
			}

			x0 -= m0;
			x1 -= m1;
		}

		x1 = p2.position.x;
		m1 = (p2.position.x - p3.position.x)/(p2.position.y - p3.position.y);
		for (int y = p2.position.y; y >= p3.position.y; y--)
		{
			for (int x = x0; x >= x1; x--)
			{
				vec2 p = (vec2){x, y};
				vec2 p1_p = vec2Sub(p, p1.position);
				vec2 p2_p = vec2Sub(p, p2.position);
				vec2 p3_p = vec2Sub(p, p3.position);
				float alpha = vec3Mag(vec2Cross(p2_p, p3_p))/triangleArea;
				float beta = vec3Mag(vec2Cross(p1_p, p3_p))/triangleArea;
				float gamma = vec3Mag(vec2Cross(p1_p, p2_p))/triangleArea;
				color col = (color){
					clamp(alpha*p1.color.r, 0, 255) + clamp(beta*p2.color.r, 0, 255) + clamp(gamma*p3.color.r, 0, 255),
					clamp(alpha*p1.color.g, 0, 255) + clamp(beta*p2.color.g, 0, 255) + clamp(gamma*p3.color.g, 0, 255),
					clamp(alpha*p1.color.b, 0, 255) + clamp(beta*p2.color.b, 0, 255) + clamp(gamma*p3.color.b, 0, 255)
				};
				putPixel(x, y, col, canvas);
			}
			
			x0 -= m0;
			x1 -= m1;
		}
	}
}
