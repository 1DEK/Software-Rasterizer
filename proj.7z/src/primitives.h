#ifndef PRIMITIVES_H
#define PRIMITIVES_H

#include "canvas.h"
#include "vector.h"

typedef struct Point
{
	vec2 position;
	color color;
} point;

typedef struct Triangle
{
	point p1, p2, p3;
} triangle;

void putLine(vec2 p1, vec2 p2, color color, const canvas *canvas);
void putTriangleWireframe(vec2 p1, vec2 p2, vec2 p3, color color, const canvas *canvas);
void putTriangle(vec2 p1, vec2 p2, vec2 p3, color color, const canvas *canvas);

void drawShadedTriangle(triangle triangle, const canvas *canvas);

#endif // PRIMITIVES_H
