#include "vector.h"
#include <math.h>

vec2 vec2Add(vec2 v1, vec2 v2)
{
	return (vec2){v1.x + v2.x, v1.y + v2.y};
}

vec2 vec2Sub(vec2 v1, vec2 v2)
{
	return (vec2){v1.x - v2.x, v1.y - v2.y};
}

vec2 vec2Scale(vec2 v, float s)
{
	return (vec2){s*v.x, s*v.y};
}

float vec2Dot(vec2 v1, vec2 v2)
{
	return v1.x*v2.x + v1.y*v2.y;
}

vec3 vec2Cross(vec2 v1, vec2 v2)
{
	return vec3Cross((vec3){v1.x, v1.y, 0.0}, (vec3){v2.x, v2.y, 0.0});
}

float vec2Mag(vec2 v)
{
	return sqrtf(vec2Dot(v, v));
}

vec2 vec2Norm(vec2 v)
{
	float mag = vec2Mag(v);
	v.x /= mag;
	v.y /= mag;
	return v;
}

vec2 vec2Reflect(vec2 v, vec2 n)
{
	return vec2Sub(vec2Scale(n, 2.0*vec2Dot(v, n)), v);
}

vec2 vec2Perp(vec2 v)
{
	return (vec2){v.y, -v.x};
}

vec2 ray2At(ray2 ray, float t)
{
	return vec2Add(ray.origin, vec2Scale(ray.direction, t));
}

vec3 vec3Add(vec3 v1, vec3 v2)
{
	return (vec3){v1.x + v2.x, v1.y + v2.y, v1.z + v2.z};
}

vec3 vec3Sub(vec3 v1, vec3 v2)
{
	return (vec3){v1.x - v2.x, v1.y - v2.y, v1.z - v2.z};
}

vec3 vec3Scale(vec3 v, float s)
{
	return (vec3){s*v.x, s*v.y, s*v.z};
}

float vec3Dot(vec3 v1, vec3 v2)
{
	return v1.x*v2.x + v1.y*v2.y + v1.z*v2.z;
}

vec3 vec3Cross(vec3 v1, vec3 v2)
{
	return (vec3) {
		v1.y*v2.z - v1.z*v2.y,
		v1.z*v2.x - v1.x*v2.z,
		v1.x*v2.y - v1.y*v2.x
	};
}

float vec3Mag(vec3 v)
{
	return sqrtf(vec3Dot(v, v));
}

vec3 vec3Norm(vec3 v)
{
	float mag = vec3Mag(v);
	v.x /= mag;
	v.y /= mag;
	v.z /= mag;
	return v;
}

vec3 vec3Reflect(vec3 v, vec3 n)
{
	return vec3Sub(vec3Scale(n, 2.0*vec3Dot(v, n)), v);	
}

vec3 vec3Perp(vec3 v)
{
	// FIXME
	return v;
}

vec3 ray3At(ray3 ray, float t)
{
	return vec3Add(ray.origin, vec3Scale(ray.direction, t));
}
