#ifndef VECTOR_H
#define VECTOR_H

typedef struct Vec2
{
	float x, y;
} vec2;

typedef struct Ray2
{
	vec2 origin;
	vec2 direction;
} ray2;

typedef struct Vec3
{
	float x, y, z;
} vec3;

typedef struct Ray3
{
	vec3 origin;
	vec3 direction;
} ray3;

vec2 vec2Add(vec2 v1, vec2 v2);
vec2 vec2Sub(vec2 v1, vec2 v2);
vec2 vec2Scale(vec2 v, float s);
float vec2Dot(vec2 v1, vec2 v2);
vec3 vec2Cross(vec2 v1, vec2 v2);
float vec2Mag(vec2 v);
vec2 vec2Norm(vec2 v);
vec2 vec2Reflect(vec2 v, vec2 n); // reflect v around n, n has to be unit vector
vec2 vec2Perp(vec2 v);

vec2 ray2At(ray2 ray, float t);

vec3 vec3Add(vec3 v1, vec3 v2);
vec3 vec3Sub(vec3 v1, vec3 v2);
vec3 vec3Scale(vec3 v, float s);
float vec3Dot(vec3 v1, vec3 v2);
vec3 vec3Cross(vec3 v1, vec3 v2);
float vec3Mag(vec3 v);
vec3 vec3Norm(vec3 v);
vec3 vec3Reflect(vec3 v, vec3 n); // reflect v around n, n has to be unit vector
vec3 vec3Perp(vec3 v);

vec3 ray3At(ray3 ray, float t);

#endif // VECTOR_H
